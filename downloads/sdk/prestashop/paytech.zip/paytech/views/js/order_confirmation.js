/**
 * Created by PhpStorm.
 * USER: INTECH
 * Date: 05/04/2018
 * Time: 13:09
 */
$(document).ready(function() {
    $('.page-order-confirmation #order-details ul').append($('#paytech_transaction_id'));
});
