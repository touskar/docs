window.paymentPopupMode = PayTech.OPEN_IN_POPUP;
