<?php


namespace Drupal\commerce_paytech\Plugin\Commerce\PaymentGateway;
use Drupal\commerce_order\Entity\OrderInterface;
use Drupal\commerce_payment\Exception\PaymentGatewayException;
use Drupal\commerce_payment\PluginForm\PaymentOffsiteForm as BasePaymentOffsiteForm;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\Entity\Node;
class RedirectPaymentForm extends BasePaymentOffsiteForm
{
  /**
   * {@inheritdoc}
   */
  public function buildConfigurationForm(array $form, FormStateInterface $form_state)
  {

    $form = parent::buildConfigurationForm($form, $form_state);
    $urlRedirect= $this->getUrlRedirect($form);
    $data=[];
    //echo "<pre>";
   // var_dump($urlRedirect);die('');
    return $this->buildRedirectForm(
      $form,
      $form_state,
      $urlRedirect,
      $data,
      self::REDIRECT_GET
    );
  }
  private static $API_KEY;
  private static $API_SECRET;
  private static $PAYTECH_REQUEST_URL;
  private static $PAYTECH_PROCESS_URL;
  private function getData($form): array
  {

    /** @var \Drupal\commerce_payment\Entity\PaymentInterface $payment */
    $payment = $this->entity;
    global $base_url ;
    /** @var \Drupal\commerce_payment\Plugin\Commerce\PaymentGateway\OffsitePaymentGatewayInterface $payment_gateway_plugin */
    $payment_gateway_plugin = $payment->getPaymentGateway()->getPlugin();
    $configuration = $payment_gateway_plugin->getConfiguration();
    self::$API_KEY=@$configuration['api_key'];
    self::$API_SECRET=@$configuration['secret_key'];
    self::$PAYTECH_REQUEST_URL=@$configuration['posturl'];
    self::$PAYTECH_PROCESS_URL=@$configuration['posturlprocess'];
    // Order and billing address.
    $order = $payment->getOrder();
    //START
    $productName="";
    foreach ($order->getItems() as $key => $order_item) {
      $product_variation = $order_item->getPurchasedEntity();
      $productName =  $product_variation->getTitle() . " - ";
    }
    $productName =  substr($productName,0,strlen($productName) - 3);
    //END


    $billing_address = $order->getBillingProfile()->get('address');
    $plugin = $payment->getPaymentGateway()->getPlugin();
    $gateway_mode = $plugin->getMode();
    if(!preg_match("#https#",$base_url)){
        $ipn = str_replace("http","https",$base_url) . '/payment/notify/' . $payment->getPaymentGatewayId();
    }else{
        $ipn = $base_url. '/payment/notify/' . $payment->getPaymentGatewayId();
    }
    if ($gateway_mode == 'prod') {
      $mode='prod';
    }
    else {
      $mode = 'test';
    }
    return array(
      "item_name" => $productName,
      "item_price" => $payment->getAmount()->getNumber(),
      "currency" => $payment->getAmount()->getCurrencyCode(),
      "ref_command" => $payment->getOrderId() . '_' . time(),
      "command_name" => "Paiement de " . $payment->getAmount()->getNumber() . " " .  $payment->getAmount()->getCurrencyCode(). " pour ". $productName ." acheté sur Paytech" ,
      "env" => $mode,//todo change to $mode
      "success_url" => $form['#return_url'] . '?',
      "ipn_url" =>$ipn,
      "cancel_url" => $form['#cancel_url'] . '?',
      "custom_field" => json_encode([
        'order_id' =>$payment->getOrderId(),
        'city' => @$billing_address->getValue()[0]['locality'],
        'address'=> @$billing_address->getValue()[0]['address_line1'],
        'country_code'=>@$billing_address->getValue()[0]['country_code'],
        'payment_gateway'=> $payment->getPaymentGatewayId(),
      ]));
  }
  private function getUrlRedirect($form): string
  {
    $data = $this->getData($form);
   return $this->post(self::$PAYTECH_REQUEST_URL, $data, [
      "API_KEY: " . self::$API_KEY,
      "API_SECRET: " . self::$API_SECRET
    ]) ;

  }
  function post($url, $data, $header = []): string
  {

    $strPostField = http_build_query($data);
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_POSTFIELDS, $strPostField);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array_merge($header, [
      'Content-Type: application/x-www-form-urlencoded;charset=utf-8',
      'Content-Length: ' . mb_strlen($strPostField)
    ]));

    $response = curl_exec($ch);

    $jsonResponse = json_decode($response, true);
   // dd($jsonResponse);

    if (array_key_exists('token', $jsonResponse)) {
      return self::$PAYTECH_PROCESS_URL . $jsonResponse['token'];

    } else {
      return '';
    }


  }
}
