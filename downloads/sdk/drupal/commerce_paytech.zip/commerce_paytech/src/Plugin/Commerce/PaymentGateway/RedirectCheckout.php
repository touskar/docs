<?php

namespace Drupal\commerce_paytech\Plugin\Commerce\PaymentGateway;
function dd($data){
  echo "<pre>";
  var_dump($data);
  die('');
}
use Drupal\commerce_order\Entity\OrderInterface;
use Drupal\commerce_payment\PaymentMethodTypeManager;
use Drupal\commerce_payment\PaymentTypeManager;
use Drupal\commerce_payment\Plugin\Commerce\PaymentGateway\OffsitePaymentGatewayBase;
use Drupal\Component\Datetime\TimeInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\HttpFoundation\Request;

/**
 * Provides the QuickPay offsite Checkout payment gateway.
 *
 * @CommercePaymentGateway(
 *   id = "paytech_redirect_checkout",
 *   label = @Translation("Paytech (Redirect to paytech)"),
 *   display_label = @Translation("Paytech"),
 *    forms = {
 *     "offsite-payment" = "Drupal\commerce_paytech\Plugin\Commerce\PaymentGateway\RedirectPaymentForm",
 *   },
 *   modes= {
 *     "test" = "Teste",
 *     "prod" = "Production"
 *   }
 * )
 */
class RedirectCheckout extends OffsitePaymentGatewayBase {

/*//////////////////////////////////////////////////////START///////////////////////////////////////////////////////////////////////////
 * *************************************************************************************************************************************
 *                                       INITIALISATION DES PARAMETRE DE CONFIGURATION                                                 *
 * *************************************************************************************************************************************
/*//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  public function defaultConfiguration() {
    return [
        'secret_key' => '',
        'api_key' => '',
        'paytech_host'=>'https://paytech.sn/',
        'posturl'=>'https://paytech.sn/api/payment/request-payment',
        'posturlprocess'=>'https://paytech.sn/payment/checkout/'
      ] + parent::defaultConfiguration();
  }
/*//////////////////////////////////////////////////////END////////////////////////////////////////////////////////////////////////////
* *************************************************************************************************************************************
*                                       INITIALISATION DES PARAMETRE DE CONFIGURATION                                                 *
* *************************************************************************************************************************************
/*//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



/*//////////////////////////////////////////////////////START///////////////////////////////////////////////////////////////////////////
  * *************************************************************************************************************************************
  *                                       CREATION FORMULAIRE DE PARAMETRAGE                                                            *
  * *************************************************************************************************************************************
 /*/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  public function buildConfigurationForm(array $form, FormStateInterface $form_state) {
    $form = parent::buildConfigurationForm($form, $form_state);

    $form['secret_key'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Clée privée'),
      '#description' => $this->t('Il s\'agit de la clé privée de Paytech.'),
      '#default_value' => $this->configuration['secret_key'],
      '#required' => TRUE,
    ];

    $form['api_key'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Clée public'),
      '#description' => $this->t('Il s\'agit de la clé pubic de Paytech.'),
      '#default_value' => $this->configuration['api_key'],
      '#required' => TRUE,
    ];

    return $form;
  }

/*//////////////////////////////////////////////////////END////////////////////////////////////////////////////////////////////////////\
* *************************************************************************************************************************************
*                                       CREATION FORMULAIRE DE PARAMETRAGE                                                            *
* *************************************************************************************************************************************
/*//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


/*//////////////////////////////////////////////////////END////////////////////////////////////////////////////////////////////////////\
* *************************************************************************************************************************************
*                                       ENREGISTREMENT FORMULAIRE                                                                     *
* *************************************************************************************************************************************
/*//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  public function submitConfigurationForm(array &$form, FormStateInterface $form_state) {
    parent::submitConfigurationForm($form, $form_state);
    $values = $form_state->getValue($form['#parents']);
    $this->configuration['secret_key'] = $values['secret_key'];
    $this->configuration['api_key'] = $values['api_key'];
    $this->configuration['paytech_host'] = 'https://paytech.sn/';
    $this->configuration['posturl'] = 'https://paytech.sn/api/payment/request-payment';
    $this->configuration['posturlprocess'] = 'https://paytech.sn/payment/checkout/';

  }

/*//////////////////////////////////////////////////////END////////////////////////////////////////////////////////////////////////////\
* *************************************************************************************************************************************
*                                       ENREGISTREMENT FORMULAIRE                                                                     *
* *************************************************************************************************************************************
/*//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  public function __onReturn(OrderInterface $order, Request $request)
  {
    $this->updatePayment($order,'authorization');

  }
  public static $ENTITICOMMERCE;
  public function createPayment(OrderInterface $order,$refExterne){
    $logger = \Drupal::logger('commerce_paytech');
    $payment_storage = $this->entityTypeManager->getStorage('commerce_payment');
    $payment = $payment_storage->create([
      'state' => 'authorization',
      'amount' => $order->getTotalPrice(),
      'payment_gateway' => $this->entityId,
      'order_id' => $order->id(),
      'remote_id' => $refExterne,
      'remote_state' => 'pending',
    ]);
    $logger->info('Saving Payment information. Transaction reference: ' );
    $payment->save();
    drupal_set_message('Payment was processed');
    $logger->info('Payment information saved successfully. Transaction reference: ' );
    return $payment ;
  }

  public function onNotify(\Symfony\Component\HttpFoundation\Request $request)
  {
    $custom = json_decode(stripslashes(@$_POST['custom_field']), true);// see stripslashes
    $orders = \Drupal::entityTypeManager()
      ->getStorage('commerce_order')
      ->load( @$custom['order_id']);
    /** @var \Drupal\commerce_payment\Entity\PaymentInterface $payment */
    $payment = $this->createPayment($orders,@$_POST['token']);

    if (!empty($this->configuration['api_logging']['response'])) {
      \Drupal::logger('commerce_ingenico')
        ->debug('e-Commerce notification: <pre>@body</pre>', [
          '@body' => var_export($request->query->all(), TRUE),
        ]);
    }

    /** @var \Drupal\commerce_payment\Plugin\Commerce\PaymentGateway\OffsitePaymentGatewayInterface $payment_gateway_plugin */
    if($payment){
      $payment_gateway_plugin = $payment->getPaymentGateway()->getPlugin();
      $options = $payment_gateway_plugin->getConfiguration();
    }else{
      die("Pas de paiement trouvé");
    }

    if (isset($_POST['type_event'])) {
        $res = $_POST['type_event'];
        if ($res === 'sale_complete' && hash('sha256', $options['api_key']) === @$_POST['api_key_sha256'] && hash('sha256', $options['secret_key']) === @$_POST['api_secret_sha256']) {
          $paymentMethod = @$_POST['payment_method'];
          $message = "Le paiement a été effectué avec succès sur PayTech via $paymentMethod";
          $payment->set('state', 'completed');
          $payment->set('remote_state', 'success');
          $payment->save();
          die($message);
        }
        else{
          $payment->set('state', 'failed');
          $payment->save();
          die('Not from Paytech');
        }
      }
      die('Type event not matched');
  }
}
